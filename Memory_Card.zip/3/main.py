from random import choice, shuffle
from time import sleep
from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QPalette, QColor

app = QApplication([])

# Встановлюємо темну тему
palette = QPalette()
palette.setColor(QPalette.Window, QColor(40, 40, 40))
palette.setColor(QPalette.WindowText, QColor(220, 220, 220))
palette.setColor(QPalette.Button, QColor(80, 80, 80))
palette.setColor(QPalette.ButtonText, QColor(255, 255, 255))
app.setPalette(palette)

from main_window import *

class Question:
    def __init__(self, question, answer, wrong_answer1, wrong_answer2, wrong_answer3):
        self.question = question
        self.answer = answer
        self.wrong_answers = [wrong_answer1, wrong_answer2, wrong_answer3]
        self.count_ask = 0
        self.count_right = 0

    def got_right(self):
        self.count_ask += 1
        self.count_right += 1

    def got_wrong(self):
        self.count_ask += 1

q1 = Question('Яблуко', 'apple', 'application', 'pinapple', 'apply')
q2 = Question('Дім', 'house', 'horse', 'hurry', 'hour')
q3 = Question('Миша', 'mouse', 'mouth', 'muse', 'museum')
q4 = Question('Число', 'number', 'digit', 'amount', 'summary')

radio_buttons = [rb_ans1, rb_ans2, rb_ans3, rb_ans4]
questions = [q1, q2, q3, q4]

def update_progress():
    total = sum(q.count_ask for q in questions)
    correct = sum(q.count_right for q in questions)
    percentage = (correct / total) * 100 if total > 0 else 0
    color = "green" if percentage > 70 else "orange" if percentage > 40 else "red"
    progress_bar.setStyleSheet(f"background-color: {color}; height: 5px;")
    progress_bar.setText(f"Успішність: {round(percentage, 2)}%")

def new_question():
    global cur_q
    cur_q = choice(questions)
    lb_question.setText(cur_q.question)
    lb_right_answer.setText(cur_q.answer)
    
    answers = cur_q.wrong_answers + [cur_q.answer]
    shuffle(answers)
    
    for btn, text in zip(radio_buttons, answers):
        btn.setText(text)

    update_progress()

new_question()

def check():
    for answer in radio_buttons:
        if answer.isChecked():
            if answer.text() == cur_q.answer:
                cur_q.got_right()
                lb_result.setText('✅ Вірно!')
            else:
                lb_result.setText('❌ Не вірно!')
                cur_q.got_wrong()
            answer.setChecked(False)
            break
    update_progress()

def click_ok():
    if btn_next.text() == 'Відповісти':
        check()
        gb_question.hide()
        gb_answer.show()
        btn_next.setText('Наступне запитання')
    else:
        new_question()
        gb_question.show()
        gb_answer.hide()
        btn_next.setText('Відповісти')

btn_next.clicked.connect(click_ok)

window.show()
app.exec_()
