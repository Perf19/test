from PyQt5.QtWidgets import QWidget, QVBoxLayout, QGroupBox, QButtonGroup, QRadioButton, QPushButton, QLabel, QFrame
from PyQt5.QtCore import Qt

window = QWidget()

btn_next = QPushButton('Відповісти')
btn_next.setStyleSheet("background-color: #555; padding: 8px; font-size: 14px;")

rb_ans1 = QRadioButton()
rb_ans2 = QRadioButton()
rb_ans3 = QRadioButton()
rb_ans4 = QRadioButton()

for btn in [rb_ans1, rb_ans2, rb_ans3, rb_ans4]:
    btn.setStyleSheet("border-radius: 8px; padding: 6px; background-color: #333; color: white;")

RadioGroup = QButtonGroup()
RadioGroup.addButton(rb_ans1)
RadioGroup.addButton(rb_ans2)
RadioGroup.addButton(rb_ans3)
RadioGroup.addButton(rb_ans4)

lb_question = QLabel('Запитання')
lb_question.setStyleSheet("font-size: 18px; font-weight: bold;")

lb_result = QLabel()
lb_right_answer = QLabel()

gb_question = QGroupBox('Варіанти відповідей')
gb_answer = QGroupBox()

vl_answers = QVBoxLayout()
vl_answers.addWidget(rb_ans1)
vl_answers.addWidget(rb_ans2)
vl_answers.addWidget(rb_ans3)
vl_answers.addWidget(rb_ans4)

gb_question.setLayout(vl_answers)

vl_answer_result = QVBoxLayout()
vl_answer_result.addWidget(lb_result)
vl_answer_result.addWidget(lb_right_answer)
gb_answer.setLayout(vl_answer_result)

progress_bar = QLabel()
progress_bar.setStyleSheet("background-color: red; height: 5px;")
progress_bar.setAlignment(Qt.AlignCenter)

layout = QVBoxLayout()
layout.addWidget(progress_bar)
layout.addWidget(lb_question, alignment=Qt.AlignHCenter)
layout.addWidget(gb_question)
layout.addWidget(gb_answer)
layout.addWidget(btn_next, alignment=Qt.AlignHCenter)

gb_answer.hide()

window.setLayout(layout)
window.setStyleSheet("background-color: #222; color: white; padding: 20px;")
window.resize(400, 300)
